package com.api.taylor.controllers;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CDemandesTest {


    @Autowired
    private CDemandes cDemandes;
    @Test
    @Disabled
    void update() {

    }
}