package com.api.taylor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaylorApplicationTests {

	@Test
	void contextLoads() {
	}

}
